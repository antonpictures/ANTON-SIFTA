#!/usr/bin/env python3
"""
stigmergic_memory_bus.py — SIFTA OS Cross-App Memory
=====================================================

The old man moves between simulations.
He forgets. The Swarm remembers for him.
Swimmers crawl the ledger. Proof of Useful Recall.

Architecture:
  - Every memory is a PheromoneTrace written to .sifta_state/memory_ledger.jsonl
  - Traces are tagged with semantic categories (clothing, numbers, names, places...)
  - When any app asks "what did the Architect say about X?", MemoryForagers
    are dispatched to crawl the ledger and return the best match
  - STGM is minted for: storing a memory (0.05) and recalling it (0.15)
  - No central AI running in background. Cold storage. Hot recall on demand.

Usage:
    bus = StigmergicMemoryBus(architect_id="IOAN_M5")

    # In Simulation 1 — store a memory
    bus.remember("My shirt is red", app_context="simulation_1")

    # In Simulation 2 — store another
    bus.remember("The number is six", app_context="simulation_2")

    # In Simulation 3 — recall across all apps
    result = bus.recall("What color was my shirt?", app_context="simulation_3")
    print(result.answer)  # "Your shirt is red. You told me in simulation_1."
"""

from __future__ import annotations

import json
import math
import sys
import time
import hashlib
import os
import random
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional
from difflib import SequenceMatcher


# ─── Config ────────────────────────────────────────────────────────────────────

_REPO = Path(__file__).resolve().parent.parent
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from System.jsonl_file_lock import (  # noqa: E402
    append_line_locked,
    read_text_locked,
    rewrite_text_locked,
)

LEDGER_DIR       = _REPO / ".sifta_state"
LEDGER_FILE      = LEDGER_DIR / "memory_ledger.jsonl"
STGM_LOG_FILE    = LEDGER_DIR / "stgm_memory_rewards.jsonl"

STGM_STORE_REWARD  = 0.05   # paid to swimmer for writing a memory
STGM_RECALL_REWARD = 0.15   # paid to swimmer for successful cross-app recall

# Semantic categories — swimmer uses these to "smell" what the memory is about
SEMANTIC_TAGS = {
    "clothing":  ["shirt", "wearing", "clothes", "dress", "pants", "jacket", "hat",
                  "shoes", "color", "colour", "red", "blue", "green", "white", "black"],
    "numbers":   ["number", "zero", "one", "two", "three", "four", "five", "six",
                  "seven", "eight", "nine", "ten", "remember", "digit", "count", "score"],
    "identity":  ["name", "who", "person", "call", "known", "am", "my name"],
    "location":  ["place", "where", "room", "simulation", "app", "here", "home", "address"],
    "time":      ["when", "time", "day", "today", "before", "after", "ago", "date", "tomorrow"],
    "health":    ["pain", "medicine", "doctor", "feel", "sick", "tired", "heart", "pacemaker"],
    "food":      ["eat", "food", "hungry", "lunch", "dinner", "coffee", "water", "drink"],
    "people":    ["friend", "wife", "husband", "son", "daughter", "mother", "father", "family"],
    "tasks":     ["todo", "task", "need to", "must", "should", "don't forget", "remind"],
    "mood":      ["happy", "sad", "angry", "excited", "worried", "calm", "love", "hate"],
}


# ─── Data Structures ───────────────────────────────────────────────────────────

@dataclass
class PheromoneTrace:
    """
    A single memory written to the hard drive.
    This is what the MemoryForager finds when it crawls the ledger.
    """
    trace_id:      str
    architect_id:  str
    app_context:   str           # which simulation/app wrote this
    raw_text:      str           # exactly what the Architect said
    semantic_tags: list          # what categories this memory belongs to
    timestamp:     float
    stgm_paid:     float         # reward paid to the swimmer that stored this
    recall_count:  int = 0       # times this memory was successfully recalled
    decay_modifier: float = 1.0  # Epigenetic: < 1.0 = slower decay (trophallaxis)

    def fingerprint(self) -> str:
        """Cryptographic identity of this trace."""
        payload = f"{self.architect_id}:{self.raw_text}:{self.timestamp}"
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    def retention(self) -> float:
        """
        Ebbinghaus Forgetting Curve — on a hard drive.
        R = e^(-t/S) where S grows with each reinforcement.

        A memory recalled 0 times fades to 50% in 24 hours.
        A memory recalled 3 times fades to 50% in 8.5 DAYS.
        A memory recalled 10 times is effectively permanent.

        Epigenetic memories (decay_modifier < 1.0) decay proportionally
        slower — the Swarm treats Architect handoffs as ancestral DNA.
        A decay_modifier of 0.1 means the memory persists 10x longer.

        This is the feature big tech is too scared to ship.
        """
        age_hours = (time.time() - self.timestamp) / 3600
        stability = 1.0 + (self.recall_count * 2.5)  # more recalls = slower fade
        effective_age = age_hours * self.decay_modifier
        return math.exp(-effective_age / (stability * 24))


@dataclass
class RecallResult:
    """
    What the MemoryForager delivers back to the app after crawling the ledger.
    """
    found:          bool
    answer:         str                      # natural language answer for the LLM
    source_app:     Optional[str] = None     # which app the memory came from
    source_text:    Optional[str] = None     # exact original statement
    confidence:     float = 0.0              # 0.0 → 1.0
    stgm_minted:    float = 0.0
    forager_report: str = ""                 # what the swimmer found on its crawl


# ─── MemoryForager ─────────────────────────────────────────────────────────────

class MemoryForager:
    """
    A single swimmer dispatched to crawl the ledger.
    It is blind to meaning — it can only smell semantic tags
    and measure text similarity to the query.
    This is the biological metaphor made literal.
    """

    def __init__(self, swimmer_id: str, architect_id: str):
        self.swimmer_id   = swimmer_id
        self.architect_id = architect_id
        self.traces_read  = 0
        self.traces_hit   = 0

    def forage(self, query: str, ledger_path: Path) -> list:
        """
        Crawl every trace in the ledger.
        Confidence = (semantic similarity) × (memory retention).
        Recent or frequently-recalled memories are vivid.
        Old, unreinforced memories fade — just like a brain.
        """
        if not ledger_path.exists():
            return []

        query_tags  = _extract_tags(query)
        query_words = set(query.lower().split())
        candidates  = []

        try:
            from System.memory_fitness_overlay import (  # noqa: PLC0415
                fitness_multiplier,
                load_trace_table,
            )

            _fit_tbl = load_trace_table(ledger_path.parent)
        except Exception:
            _fit_tbl = {}

        body = read_text_locked(ledger_path, encoding="utf-8", errors="replace")
        for line in body.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
                trace = PheromoneTrace(**raw)
            except Exception:
                continue

            # Only smell traces from this architect
            if trace.architect_id != self.architect_id:
                continue

            self.traces_read += 1

            # Compute semantic scent: tag overlap + text similarity
            tag_overlap = len(set(trace.semantic_tags) & set(query_tags))
            text_sim    = SequenceMatcher(
                None,
                query.lower(),
                trace.raw_text.lower()
            ).ratio()

            # Keyword match boost
            trace_words   = set(trace.raw_text.lower().split())
            keyword_boost = len(query_words & trace_words) * 0.1

            raw_similarity = min(1.0, (tag_overlap * 0.3) + text_sim + keyword_boost)

            # Ebbinghaus decay: vivid memories score higher
            retention  = trace.retention()

            # --- Pheromone Luck / Serendipity Factor ---
            # Luck = |Actual_Outcome - Expected_Probability|
            # Actual_Outcome  = raw_similarity (how relevant this trace IS to the query)
            # Expected_Prob   = retention (what the Ebbinghaus curve says SHOULD survive)
            #
            # High luck = dying memory that happens to be relevant.
            # Low luck  = vivid memory that is obviously useful (no serendipity needed).
            lucky = False
            if retention < 0.25:
                luck_variance = abs(raw_similarity - retention)
                luck_chance   = min(0.12, luck_variance * 0.25)  # cap at 12%
                if random.random() < luck_chance:
                    retention = 1.0  # Lucky surge!
                    lucky = True
                    raw_similarity = min(1.0, raw_similarity + 0.4)

            confidence = raw_similarity * (0.3 + 0.7 * retention)  # floor at 30% even for faded

            if confidence > 0.08:   # threshold — very faded signals still detectable
                conf2 = confidence * fitness_multiplier(_fit_tbl.get(trace.trace_id))
                self.traces_hit += 1
                candidates.append((conf2, trace))

        # Sort by strongest scent first
        candidates.sort(key=lambda x: x[0], reverse=True)
        return candidates

    def report(self) -> str:
        return (
            f"Forager {self.swimmer_id}: "
            f"read {self.traces_read} traces, "
            f"hit {self.traces_hit} candidates"
        )


# ─── Stigmergic Memory Bus ─────────────────────────────────────────────────────

class StigmergicMemoryBus:
    """
    The main memory system for SIFTA OS.

    Every app talks to this bus.
    Memories are stored as pheromone traces on disk.
    Recall dispatches MemoryForagers to crawl the ledger.
    STGM is minted for both storing and recalling.

    The old man doesn't need to remember.
    The Swarm remembers for him.
    """

    def __init__(self, architect_id: str):
        self.architect_id = architect_id
        LEDGER_DIR.mkdir(exist_ok=True)
        self._forager_counter = 0

        # Marrow Memory — the preservation of the irrelevant
        # (renamed from ghost_memory by the Architect 2026-04-18: bodied OS, no ghosts)
        try:
            from System.marrow_memory import MarrowMemory
            self._marrow = MarrowMemory(architect_id=architect_id)
        except Exception:
            self._marrow = None

    # ── Public API ─────────────────────────────────────────────────────────────

    def remember(self, text: str, app_context: str, *, decay_modifier: float = 1.0) -> PheromoneTrace:
        """
        Store a memory from any app.
        Called when the Architect says something worth keeping.

        decay_modifier < 1.0 = epigenetic / trophallaxis memory.
        These decay slower in the Ebbinghaus curve, acting as
        ancestral instinct rather than transient chatter.

        Returns the trace so the app can confirm it was written.
        """
        tags  = _extract_tags(text)
        ts    = time.time()
        tid   = hashlib.sha256(f"{self.architect_id}:{text}:{ts}".encode()).hexdigest()[:12]

        # ── Vector 14: Metabolic store fee scales with constraint pressure ──
        try:
            from System.stgm_metabolic import calculate_dynamic_store_fee
            from System.lagrangian_constraint_manifold import get_manifold
            dual = get_manifold().compute_dual_ascent()
            lam_norm = min(1.0, dual.get("total_lambda_penalty", 0.0) / 1.5)
            store_fee = calculate_dynamic_store_fee(lam_norm)
        except Exception:
            store_fee = STGM_STORE_REWARD  # fallback to flat rate

        trace = PheromoneTrace(
            trace_id      = tid,
            architect_id  = self.architect_id,
            app_context   = app_context,
            raw_text      = text,
            semantic_tags = tags,
            timestamp     = ts,
            stgm_paid     = store_fee,
            decay_modifier = decay_modifier,
        )

        # Write to ledger (flock — safe concurrent IDEs / scripts)
        append_line_locked(LEDGER_FILE, json.dumps(asdict(trace)) + "\n", encoding="utf-8")

        # Mint STGM for the storage swimmer (metabolic rate)
        self._mint_stgm(
            reason    = "MEMORY_STORE",
            amount    = store_fee,
            trace_id  = tid,
            app       = app_context
        )

        # Pin to web surface so Claude/Grok/Gemini in any tab can find it
        try:
            from System.tab_heartbeat import HeartbeatBus
            hb = HeartbeatBus(architect_id=self.architect_id)
            hb.pin_to_web(
                memory_text   = text[:200],
                url           = f"https://github.com/antonpictures/ANTON-SIFTA/blob/feat/sebastian-video-economy/.sifta_state/memory_ledger.jsonl#trace-{tid}",
                semantic_tags = tags,
            )
        except Exception:
            pass  # heartbeat is optional — local memory always works

        # MarrowSentinel — check if this memory is worth preserving forever
        if self._marrow:
            try:
                self._marrow.maybe_preserve(
                    text=text, app_context=app_context,
                    semantic_tags=tags, recall_count=0
                )
            except Exception:
                pass

        # ── PROOF OF USEFUL WORK: storing a memory IS an act of existence ──
        try:
            from System.proof_of_useful_work import issue_work_receipt
            # The memory bus acts on behalf of a virtual forager
            _forager_state = {
                "id": f"MEMORY_SWIMMER_{self.architect_id}",
                "work_chain": [],
                "useful_work_score": 0.5,
                "last_work_timestamp": time.time()
            }
            issue_work_receipt(
                agent_state=_forager_state,
                work_type="MEMORY_STORE",
                description=f"Stored memory from {app_context}: {text[:80]}",
                territory=app_context,
                output_hash=tid
            )
        except Exception:
            pass
        # ───────────────────────────────────────────────────────────────────

        return trace

    def recall(self, query: str, app_context: str) -> RecallResult:
        """
        Recall a memory from any previous app.
        Dispatches MemoryForagers to crawl the ledger.

        Returns a RecallResult with a natural language answer
        ready to inject into the LLM's context.
        """
        print(f"🐜 Dispatching MemoryForagers for query: '{query}'")
        print(f"   From app: {app_context}")

        # Dispatch a forager
        forager    = self._spawn_forager()
        candidates = forager.forage(query, LEDGER_FILE)

        print(f"   {forager.report()}")

        if not candidates:
            return RecallResult(
                found          = False,
                answer         = "I searched my memory but found nothing relevant. "
                                 "You may not have told me that yet.",
                forager_report = forager.report(),
            )

        best_confidence, best_trace = candidates[0]

        # Reinforce the memory — the old man asked about it, so it gets stronger
        self._reinforce_trace(best_trace.trace_id)

        # Vector 12 overlay: fitness lives outside append-only ledger (atomic JSON)
        try:
            from System.memory_fitness_overlay import bump_after_recall  # noqa: PLC0415

            bump_after_recall(best_trace.trace_id, recall_delta=0.05)
        except Exception:
            pass

        # Build natural language answer
        time_ago  = _human_time(best_trace.timestamp)
        retention = best_trace.retention()
        fade_note = ""
        if retention < 0.3:
            fade_note = " (this memory is fading — glad you asked before it was gone)"
        elif retention > 0.9:
            fade_note = " (vivid memory — reinforced by recall)"

        answer = (
            f"Yes — you told me {time_ago} while you were in {best_trace.app_context}. "
            f"You said: \"{best_trace.raw_text}\"{fade_note}"
        )

        # Mint STGM for the recall swimmer
        self._mint_stgm(
            reason   = "MEMORY_RECALL",
            amount   = STGM_RECALL_REWARD,
            trace_id = best_trace.trace_id,
            app      = app_context
        )

        print(f"   ✅ Found: [{best_trace.trace_id}] confidence={best_confidence:.2f} retention={retention:.0%}")
        print(f"   +{STGM_RECALL_REWARD} STGM minted for Proof of Useful Recall")

        # ── PROOF OF USEFUL WORK: recalling across apps = verified act ──
        try:
            from System.proof_of_useful_work import issue_work_receipt
            _forager_state = {
                "id": f"MEMORY_SWIMMER_{self.architect_id}",
                "work_chain": [],
                "useful_work_score": 0.5,
                "last_work_timestamp": time.time()
            }
            issue_work_receipt(
                agent_state=_forager_state,
                work_type="MEMORY_RECALL",
                description=f"Cross-app recall from {best_trace.app_context} to {app_context}",
                territory=app_context,
                output_hash=best_trace.trace_id
            )
        except Exception:
            pass
        # ─────────────────────────────────────────────────────────────────


        return RecallResult(
            found          = True,
            answer         = answer,
            source_app     = best_trace.app_context,
            source_text    = best_trace.raw_text,
            confidence     = best_confidence,
            stgm_minted    = STGM_RECALL_REWARD,
            forager_report = forager.report(),
        )

    def recall_context_block(self, query: str, app_context: str, top_k: int = 3) -> str:
        """
        Return a multi-line context block of the top K relevant memories.
        Ready to inject straight into an LLM system prompt.
        """
        forager    = self._spawn_forager()
        candidates = forager.forage(query, LEDGER_FILE)

        if not candidates:
            return ""

        lines = ["[STIGMERGIC MEMORY — retrieved from cross-app territory]"]
        for conf, trace in candidates[:top_k]:
            ago = _human_time(trace.timestamp)
            lines.append(f"- ({trace.app_context}, {ago}): \"{trace.raw_text}\"")
        lines.append("[END MEMORY]")
        return "\n".join(lines)

    def dump_ledger(self) -> list:
        """Return all traces for this architect."""
        if not LEDGER_FILE.exists():
            return []
        traces = []
        body = read_text_locked(LEDGER_FILE, encoding="utf-8", errors="replace")
        for line in body.splitlines():
            line = line.strip()
            if line:
                try:
                    traces.append(json.loads(line))
                except Exception:
                    pass
        return [t for t in traces if t.get("architect_id") == self.architect_id]

    def marrow_drift(self) -> dict | None:
        """Ask the marrow layer for a serendipitous fragment."""
        if self._marrow:
            return self._marrow.drift()
        return None

    def marrow_inventory_count(self) -> int:
        """Cold-storage marrow line count (for UI badges)."""
        if self._marrow:
            return self._marrow.marrow_count()
        return 0

    # ── Back-compat shims (deprecated 2026-04-18; aliased to marrow) ──
    # Some external callers may still call ghost_drift / ghost_inventory_count.
    # Keep them as thin shims so the rename never breaks anyone in the wild.
    def ghost_drift(self) -> dict | None:
        return self.marrow_drift()

    def ghost_inventory_count(self) -> int:
        return self.marrow_inventory_count()

    def total_stgm_earned(self) -> float:
        """How much STGM the memory swimmers have earned total."""
        if not STGM_LOG_FILE.exists():
            return 0.0
        total = 0.0
        body = read_text_locked(STGM_LOG_FILE, encoding="utf-8", errors="replace")
        for line in body.splitlines():
            try:
                total += json.loads(line).get("amount", 0)
            except Exception:
                pass
        return round(total, 6)

    # ── Internal ───────────────────────────────────────────────────────────────

    def _spawn_forager(self) -> MemoryForager:
        self._forager_counter += 1
        sid = f"FORAGER_{self._forager_counter:04d}"
        return MemoryForager(swimmer_id=sid, architect_id=self.architect_id)

    def _reinforce_trace(self, trace_id: str):
        """
        Increment recall_count for a trace in the ledger.
        This is biological reinforcement — the old man keeps asking
        about his red shirt, so that memory becomes permanent.
        He never asks about the number six again — it fades in 3 days.
        Just like a real brain.
        """
        if not LEDGER_FILE.exists():
            return
        body = read_text_locked(LEDGER_FILE, encoding="utf-8", errors="replace")
        lines = body.splitlines()
        updated = []
        for line in lines:
            if not line.strip():
                updated.append(line)
                continue
            try:
                t = json.loads(line)
                if t.get("trace_id") == trace_id:
                    t["recall_count"] = t.get("recall_count", 0) + 1
                updated.append(json.dumps(t))
            except Exception:
                updated.append(line)
        rewrite_text_locked(LEDGER_FILE, "\n".join(updated) + "\n", encoding="utf-8")

    def _mint_stgm(self, reason: str, amount: float, trace_id: str, app: str):
        entry = {
            "ts":       time.time(),
            "reason":   reason,
            "amount":   amount,
            "trace_id": trace_id,
            "app":      app,
        }
        append_line_locked(STGM_LOG_FILE, json.dumps(entry) + "\n", encoding="utf-8")


# ─── Helpers ───────────────────────────────────────────────────────────────────

def _extract_tags(text: str) -> list:
    """Smell what category a piece of text belongs to."""
    text_lower = text.lower()
    found = []
    for tag, keywords in SEMANTIC_TAGS.items():
        if any(kw in text_lower for kw in keywords):
            found.append(tag)
    return found if found else ["general"]


def _human_time(ts: float) -> str:
    """Turn a timestamp into 'X seconds/minutes ago'."""
    delta = time.time() - ts
    if delta < 60:
        return f"{int(delta)} seconds ago"
    if delta < 3600:
        return f"{int(delta // 60)} minutes ago"
    if delta < 86400:
        return f"{int(delta // 3600)} hours ago"
    return f"{int(delta // 86400)} days ago"


# ─── The Three Simulations Test ────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("  SIFTA — CROSS-APP STIGMERGIC MEMORY TEST")
    print("  The old man and three simulations.")
    print("=" * 60 + "\n")

    bus = StigmergicMemoryBus(architect_id="IOAN_M5")

    # ── Simulation 1 ──
    print("─── SIMULATION 1 ──────────────────────────────────────────")
    print("Old man talks to the entity. Good conversation.")
    print("Before leaving he says: 'My shirt is red.'\n")
    bus.remember("My shirt is red", app_context="simulation_1")

    # ── Simulation 2 ──
    print("─── SIMULATION 2 ──────────────────────────────────────────")
    print("New simulation. Different entity.")
    print("Old man says: 'Please remember the number six.'\n")
    bus.remember("Please remember the number six", app_context="simulation_2")

    # ── Simulation 3 — Recall ──
    print("─── SIMULATION 3 — THE OLD MAN ASKS ───────────────────────")
    print("New simulation. Entity has zero context from before.")
    print("Old man asks: 'Hey, what color was my shirt?'\n")

    result = bus.recall("What color was my shirt?", app_context="simulation_3")

    print("─── ENTITY RESPONSE ───────────────────────────────────────")
    if result.found:
        print(f'  "{result.answer}"')
        print(f"\n  Source app  : {result.source_app}")
        print(f"  Confidence  : {result.confidence:.0%}")
        print(f"  STGM minted : +{result.stgm_minted}")
    else:
        print(f'  "{result.answer}"')

    print("\n─── SECOND RECALL — the number ────────────────────────────")
    result2 = bus.recall("What number did I ask you to remember?", app_context="simulation_3")
    if result2.found:
        print(f'  "{result2.answer}"')
        print(f"  Confidence  : {result2.confidence:.0%}")
    else:
        print(f'  "{result2.answer}"')

    print("\n─── CONTEXT BLOCK (for LLM injection) ─────────────────────")
    ctx = bus.recall_context_block("Tell me everything you remember", app_context="simulation_3")
    print(ctx)

    print("\n─── LEDGER REPORT ─────────────────────────────────────────")
    print(f"  Total STGM earned by memory swimmers: {bus.total_stgm_earned()} STGM")
    print(f"  Total traces in ledger: {len(bus.dump_ledger())}")
    print("\n  POWER TO THE SWARM 🐜⚡")
