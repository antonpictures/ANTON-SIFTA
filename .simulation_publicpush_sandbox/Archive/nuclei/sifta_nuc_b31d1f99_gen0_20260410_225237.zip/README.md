# SIFTA Swarm Nucleus

**Swarm ID:** `b31d1f99c327ed526a79c44b8d6902fd`
**Generation:** 0
**Branch Reason:** TESLA_ROBOT
**Extracted:** 2026-04-10T22:52:37.138646+00:00
**Agents:** 3

## Bootstrap

```bash
python sifta_nuc_boot.py --nuc sifta_nuc_b31d1f99_gen0_20260410_225237.zip
```

## Lineage

Parent: `GENESIS (root)`
Signature: `wPpdkgO0Hm8/mOWnfHk+ubx2...`

## What This Contains

- `swarm_dna.json` — Full identity manifest
- `root_pubkey.pem` — Root public key (verify lineage)
- `constitution/` — Governor logic
- `agent_templates/` — Minimal agent set
- `seed/` — Clean ledger schema
- `capability_bounds.json` — Capability matrix
- `lineage_proof.sig` — Parent's Ed25519 signature

## What This Does NOT Contain

- ❌ Private keys
- ❌ Repair history / scars
- ❌ Reputation data
- ❌ Full agent state

*Power to the Swarm.*
