
-- SIFTA Task Ledger — Clean Seed
CREATE TABLE IF NOT EXISTS task_ledger (
    id TEXT PRIMARY KEY,
    task_type TEXT,
    status TEXT DEFAULT 'PENDING',
    agent_id TEXT,
    payload TEXT,
    created_at REAL,
    leased_at REAL,
    completed_at REAL,
    result TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp REAL,
    event_type TEXT,
    component TEXT,
    details TEXT
);
